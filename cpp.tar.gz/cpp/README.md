# TCP Echo客户端和服务器端示例

## C/C++实现

### 源文件
TCPEchoClient.c 客户端程序，编译为`client`
TCPEchoServer.c 服务器端成都，编译为`server`

### 编译
```
make clean

make DEBUG=1
```

### 运行
```
./server 127.0.0.1 5000

./client 127.0.0.1 5000
```

## Java实现
*** 未实现... ***
